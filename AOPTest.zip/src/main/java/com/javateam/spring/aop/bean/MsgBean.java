package com.javateam.spring.aop.bean;

public interface MsgBean {
	
	public void setMsg();

}